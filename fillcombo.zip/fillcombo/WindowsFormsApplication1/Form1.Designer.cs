﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fillComboWithFlag1 = new fillcombo.FillComboWithFlag();
            this.SuspendLayout();
            // 
            // fillComboWithFlag1
            // 
            this.fillComboWithFlag1.BackColor = System.Drawing.SystemColors.Control;
            this.fillComboWithFlag1.Cursor = System.Windows.Forms.Cursors.Default;
            this.fillComboWithFlag1.Location = new System.Drawing.Point(79, 56);
            this.fillComboWithFlag1.Name = "fillComboWithFlag1";
            this.fillComboWithFlag1.Size = new System.Drawing.Size(226, 21);
            this.fillComboWithFlag1.TabIndex = 0;
            this.fillComboWithFlag1.text = "+20";
            this.fillComboWithFlag1.Load += new System.EventHandler(this.fillComboWithFlag1_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(422, 504);
            this.Controls.Add(this.fillComboWithFlag1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private fillcombo.FillComboWithFlag fillComboWithFlag1;

        

    }
}

