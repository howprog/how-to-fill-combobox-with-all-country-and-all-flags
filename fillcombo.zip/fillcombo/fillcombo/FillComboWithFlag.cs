﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Collections;
using System.Threading;

namespace fillcombo
{
    public partial class FillComboWithFlag: UserControl
    {
        public FillComboWithFlag()
        {
            InitializeComponent();
        }
        public string text
        {
            set
            {
                textBox1.Text = value;
            }
            get
            {
                return textBox1.Text;
            }
        }
         List<string> GetResourceNames()

        {
            List<string> resources = new List<string>();
            foreach (var item in Directory.GetFiles(Directory.GetCurrentDirectory()+"\\flags"))
            {
                resources.Add(item);
            }

           

               return resources;

        }

        private void UserControl1_Resize(object sender, EventArgs e)
        {
            if (comboBox1.Width < 218)
            {
                this.Width = 218;
            }
            if (pol)
            {
                this.Height = 421;
                pol = false;
            }
            else
            {
                this.Height = 21;
            }
            //this.Height = 21;
            //this.Width = comboBox1.Width+3;
            //this.Height = comboBox1.Height;
            panel1.Width = comboBox1.Width;
            comboBox1.Width = this.Width;
            comboBox1.Height = this.Height;
        }
        string _country = "";
        string _pic = "";
        int _pictop=0;
        int _picwidth = 0;
        int _combotop = 0;
        int _combowidth = 0;
        string _getClik = "";
        Queue<string> AddPath = new Queue<string>();
        PictureBox ppo = null;
        Label cmb = null;
        private void UserControl1_Load(object sender, EventArgs e)
        {
            _pictop = pictureBox2.Top;
            _picwidth = pictureBox2.Left;
            _combotop = label1.Top;
            _combowidth = label1.Left;
            List<string> _getPic = GetResourceNames();
            this.Width = comboBox1.Width;
            this.Height = comboBox1.Height;
            panel1.Width = comboBox1.Width;
           
            string _ant = "";
            int i = 1;
            int j = 1;
            string _picc="";
            StreamReader sr = new StreamReader(Directory.GetCurrentDirectory() + "\\codenumbercalling.txt");
            while((_ant=sr.ReadLine())!=null)
            {
                if (j==1)
                {
                    _country = _ant;
                    j++;
                    continue;
                }
                if (j == 2)
                {
                   _picc=  _getPic.Find(x=>x.EndsWith((_ant.ToLower()+".gif")));
                   AddPath.Enqueue(_picc);
                   //if (string.IsNullOrEmpty(_picc))
                   //{
                   //    MessageBox.Show(_ant);
                   //}
                   ppo = new PictureBox();
                   ppo.Name = (pictureBox2.Name + i);
                   //ppo.ImageLocation = _picc;
                   ppo.BackgroundImage = Image.FromFile(_picc, true);
                   ppo.BackgroundImageLayout = ImageLayout.Stretch;
                   ppo.Top = _pictop + pictureBox2.Height+5;
                   ppo.Left = pictureBox2.Left;
                   ppo.Width = pictureBox2.Width;
                   ppo.Height = pictureBox2.Height;
                   ppo.SizeMode = PictureBoxSizeMode.StretchImage;
                   this.panel1.Controls.Add(ppo);
                   _pictop = ppo.Top;
                   GC.SuppressFinalize(_picc);
                   this.panel1.Refresh();
                   i++;
                    j++;
                    
                    
                    continue;
                }
                if (j == 3)
                {

                    AddPath.Enqueue(("+"+_ant));
                    
                    j = 1;
                    cmb = new Label();
                    cmb.Name = (comboBox1.Name + i);
                    cmb.Text = _country + "+" + _ant;
                    //cmb.Tag = "+" + _ant;
                    cmb.Top = _combotop + label1.Height+5;
                    cmb.Left = label1.Left;
                    cmb.TextAlign = ContentAlignment.MiddleLeft;
                    cmb.Width = label1.Width;
                    //cmb.DropDownStyle = ComboBoxStyle.Simple;
                    this.panel1.Controls.Add(cmb);
                    //AddPath.Enqueue(cmb.Tag.ToString());
                    AddPath.Enqueue(cmb.Text);
                    cmb.Click += cmb_Click;
                    _combotop = cmb.Top;
                    i++;

                    continue;
                }
               
            }
            //MessageBox.Show("Test");
            
        }

        void cmb_Click(object sender, EventArgs e)
        {
            Label lbl = (Label)sender;
            _getClik = lbl.Text;
            for (int i = 0; i < AddPath.Count; i++)
            {
                if (AddPath.ElementAt(i) == _getClik)
                {
                    textBox1.Text = AddPath.ElementAt(i-1);
                    pictureBox1.ImageLocation = AddPath.ElementAt(i - 2);
                    comboBox1.DropDownStyle = ComboBoxStyle.DropDown;
                    //panel1.Visible = false;
                    this.Height = comboBox1.Height;
                    break;
                }
            }
            
        }
        bool pol = false;
        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            if (this.Height == 420)
            {
                this.Height = 21;
                pol = false;
                comboBox1.DropDownStyle = ComboBoxStyle.DropDown;
            }
            else
            {
                pol = true;
                this.Height = 420;
                comboBox1.DropDownStyle = ComboBoxStyle.Simple;
            }
           
        }
       
        private void label1_Click(object sender, EventArgs e)
        {
            textBox1.Text = label1.Tag.ToString();
            pictureBox1.ImageLocation = Directory.GetCurrentDirectory() + "\\flags\\eg.gif";
            comboBox1.DropDownStyle = ComboBoxStyle.DropDown;
            //panel1.Visible = false;
            this.Height = comboBox1.Height;
        }

        private void panel1_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_Resize(object sender, EventArgs e)
        {
            //textBox1.Height = comboBox1.Height;
            //pictureBox1.Height = comboBox1.Height;
           
        }

        private void panel1_Leave(object sender, EventArgs e)
        {
            
        }

        private void UserControl1_Leave(object sender, EventArgs e)
        {
            
        }

        private void UserControl1_CursorChanged(object sender, EventArgs e)
        {
            this.Height = comboBox1.Height;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           

        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            //if (panel1.Height ==420)
            //{
            //    this.Height = 21;
            //    pol = false;
            //    comboBox1.DropDownStyle = ComboBoxStyle.DropDown;
            //}
            //else
            //{
            //    pol = true;
            //    this.Height = 420;
            //    comboBox1.DropDownStyle = ComboBoxStyle.Simple;
            //}
        }
    }
}
